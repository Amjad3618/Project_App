class Chat {
  String? title;
  String? subtitle;
  String? imageurl;

  Chat({this.title, this.subtitle, this.imageurl}) {
    title;
    subtitle;
    imageurl;
  }
}

List<Chat> data = [
  Chat(
    title: 'Sir Ali Shan',
    subtitle: 'Bano Qabil,Teacher',
    imageurl:
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTd6HNBJ9zJKOHVO82xrwGOkfx447uQ0ZbzUA&usqp=CAU',
  ),
  Chat(
    title: 'Hayat khan',
    subtitle: 'Bano Qabil',
    imageurl:
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTi7gxv27XIcL2QaBd4nNFfaqUt5n96jBrR6w&usqp=CAU',
  ),
  Chat(
    title: 'Amjad Ali',
    subtitle: 'Admin',
    imageurl:
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTNTMDCcVCEkO6Jpof4p5MQdW_K4YQvI3E7DA&usqp=CAU',
  ),
  Chat(
    title: 'Ahmed Ali',
    subtitle: 'From village',
    imageurl:
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ_xybX6OYxUggOCeOnbqalehFtJgSN_mB4Jw&usqp=CAU',
  ),
  Chat(
    title: 'Save Massages',
    subtitle: 'you changed the chat them to ',
    imageurl:
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRjPI6b_v6Yo-QTGM_4Gm0wbUpi__czutaE2Q&usqp=CAU',
  ),
  Chat(
    title: 'Areef',
    subtitle: 'Bano Qabil',
    imageurl:
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ_xybX6OYxUggOCeOnbqalehFtJgSN_mB4Jw&usqp=CAU',
  ),
  Chat(
    title: 'Nabeel',
    subtitle: 'Bano Qabil',
    imageurl:
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ_xybX6OYxUggOCeOnbqalehFtJgSN_mB4Jw&usqp=CAU',
  ),
  Chat(
    title: 'Akbar Ali',
    subtitle: 'Bano Qabil',
    imageurl:
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ_xybX6OYxUggOCeOnbqalehFtJgSN_mB4Jw&usqp=CAU',
  ),
  Chat(
    title: 'Noor khan',
    subtitle: 'Bano Qabil',
    imageurl:
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ_xybX6OYxUggOCeOnbqalehFtJgSN_mB4Jw&usqp=CAU',
  ),
  Chat(
    title: 'Sajid Ali',
    subtitle: 'Bano Qabil',
    imageurl:
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ_xybX6OYxUggOCeOnbqalehFtJgSN_mB4Jw&usqp=CAU',
  ),
  Chat(
    title: 'Ali khan',
    subtitle: 'Bano Qabil',
    imageurl:
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ_xybX6OYxUggOCeOnbqalehFtJgSN_mB4Jw&usqp=CAU',
  ),
];
